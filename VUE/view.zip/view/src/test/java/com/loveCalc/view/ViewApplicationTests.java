package com.loveCalc.view;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ViewApplicationTests {

	@Test
	void contextLoads() {
	}

}
